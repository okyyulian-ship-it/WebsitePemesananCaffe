import { useState } from "react";
import { X, QrCode, Building2, Banknote, Check } from "lucide-react";
import { useCart } from "@/context/CartContext";
import { formatRupiah } from "@/data/menu";

interface CheckoutModalProps {
  open: boolean;
  onClose: () => void;
}

type PaymentMethod = "qris" | "transfer" | "cash" | null;

export function CheckoutModal({ open, onClose }: CheckoutModalProps) {
  const { total, clearCart } = useCart();
  const [method, setMethod] = useState<PaymentMethod>(null);
  const [cashAmount, setCashAmount] = useState("");
  const [paid, setPaid] = useState(false);

  if (!open) return null;

  const cashNum = parseInt(cashAmount.replace(/\D/g, "")) || 0;
  const change = cashNum - total;

  const handlePay = () => {
    setPaid(true);
    setTimeout(() => {
      clearCart();
      setPaid(false);
      setMethod(null);
      setCashAmount("");
      onClose();
    }, 2000);
  };

  const canPay = method === "cash" ? cashNum >= total : method !== null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-foreground/40 backdrop-blur-sm" onClick={onClose} />
      <div className="relative w-full max-w-md bg-card rounded-xl shadow-2xl border border-border animate-scale-in overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-border">
          <h2 className="font-display text-xl font-semibold text-foreground">Pembayaran</h2>
          <button onClick={onClose} className="h-8 w-8 rounded-full flex items-center justify-center hover:bg-muted transition-colors text-muted-foreground">
            <X className="h-4 w-4" />
          </button>
        </div>

        {paid ? (
          <div className="p-12 flex flex-col items-center gap-4 animate-fade-up">
            <div className="h-16 w-16 rounded-full bg-accent/10 flex items-center justify-center">
              <Check className="h-8 w-8 text-accent" />
            </div>
            <p className="font-display text-lg font-semibold text-foreground">Pembayaran Berhasil!</p>
            <p className="text-sm text-muted-foreground">Terima kasih atas pesanan Anda</p>
          </div>
        ) : (
          <div className="p-5 space-y-5">
            {/* Total */}
            <div className="text-center py-3 bg-secondary rounded-lg">
              <p className="text-xs text-muted-foreground uppercase tracking-wider mb-1">Total Pembayaran</p>
              <p className="text-2xl font-bold text-foreground">{formatRupiah(total)}</p>
            </div>

            {/* Payment methods */}
            <div className="space-y-2">
              <p className="text-sm font-medium text-foreground mb-3">Metode Pembayaran</p>

              {([
                { id: "qris" as const, label: "QRIS", icon: QrCode },
                { id: "transfer" as const, label: "Transfer Bank", icon: Building2 },
                { id: "cash" as const, label: "Tunai", icon: Banknote },
              ]).map((m) => (
                <button
                  key={m.id}
                  onClick={() => setMethod(m.id)}
                  className={`w-full flex items-center gap-3 p-3.5 rounded-lg border transition-all duration-200 text-left ${
                    method === m.id
                      ? "border-accent bg-accent/5 ring-1 ring-accent"
                      : "border-border hover:border-accent/40 hover:bg-secondary/50"
                  }`}
                >
                  <m.icon className={`h-5 w-5 ${method === m.id ? "text-accent" : "text-muted-foreground"}`} />
                  <span className={`text-sm font-medium ${method === m.id ? "text-foreground" : "text-muted-foreground"}`}>{m.label}</span>
                </button>
              ))}
            </div>

            {/* Method details */}
            {method === "qris" && (
              <div className="animate-fade-up p-6 bg-secondary rounded-lg flex flex-col items-center gap-3">
                <div className="h-40 w-40 border-2 border-dashed border-border rounded-lg flex items-center justify-center">
                  <QrCode className="h-16 w-16 text-muted-foreground/40" />
                </div>
                <p className="text-xs text-muted-foreground">Scan QR code untuk membayar</p>
              </div>
            )}

            {method === "transfer" && (
              <div className="animate-fade-up p-4 bg-secondary rounded-lg space-y-3">
                <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Rekening Tujuan</p>
                {[
                  { bank: "BCA", number: "1234567890", name: "Café Elegan" },
                  { bank: "Mandiri", number: "0987654321", name: "Café Elegan" },
                ].map((acc) => (
                  <div key={acc.bank} className="flex items-center justify-between p-3 bg-card rounded-md border border-border">
                    <div>
                      <p className="text-sm font-semibold text-foreground">{acc.bank}</p>
                      <p className="text-xs text-muted-foreground">{acc.name}</p>
                    </div>
                    <p className="text-sm font-mono font-semibold text-foreground">{acc.number}</p>
                  </div>
                ))}
              </div>
            )}

            {method === "cash" && (
              <div className="animate-fade-up space-y-3">
                <div>
                  <label className="text-xs font-medium text-muted-foreground mb-1.5 block">Jumlah Uang Diterima</label>
                  <input
                    type="text"
                    value={cashAmount}
                    onChange={(e) => setCashAmount(e.target.value.replace(/[^0-9]/g, ""))}
                    placeholder="0"
                    className="w-full px-4 py-3 rounded-lg border border-border bg-card text-foreground text-lg font-semibold text-right focus:outline-none focus:ring-2 focus:ring-accent/50 focus:border-accent transition-colors"
                  />
                </div>
                {cashNum > 0 && (
                  <div className={`flex justify-between p-3 rounded-lg ${change >= 0 ? "bg-accent/10" : "bg-destructive/10"}`}>
                    <span className="text-sm font-medium text-foreground">Kembalian</span>
                    <span className={`text-sm font-bold ${change >= 0 ? "text-accent" : "text-destructive"}`}>
                      {change >= 0 ? formatRupiah(change) : "Kurang " + formatRupiah(Math.abs(change))}
                    </span>
                  </div>
                )}
              </div>
            )}

            {/* Pay button */}
            <button
              onClick={handlePay}
              disabled={!canPay}
              className="w-full py-3.5 rounded-lg bg-primary text-primary-foreground font-semibold text-sm transition-all duration-200 hover:opacity-90 active:scale-[0.98] disabled:opacity-40 disabled:cursor-not-allowed"
            >
              Bayar {formatRupiah(total)}
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
