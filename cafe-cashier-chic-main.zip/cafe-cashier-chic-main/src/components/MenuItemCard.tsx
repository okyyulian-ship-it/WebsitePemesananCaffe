import { Plus, Minus } from "lucide-react";
import { useState, useRef } from "react";
import type { MenuItem } from "@/data/menu";
import { formatRupiah } from "@/data/menu";
import { useCart } from "@/context/CartContext";

interface MenuItemCardProps {
  item: MenuItem;
}

export function MenuItemCard({ item }: MenuItemCardProps) {
  const { addItem, items, updateQuantity } = useCart();
  const [flyAnim, setFlyAnim] = useState(false);
  const imgRef = useRef<HTMLDivElement>(null);

  const cartItem = items.find((i) => i.id === item.id);
  const qty = cartItem?.quantity ?? 0;

  const handleAdd = () => {
    setFlyAnim(true);
    addItem(item);
    setTimeout(() => setFlyAnim(false), 500);
  };

  const handleMinus = () => {
    if (qty > 0) updateQuantity(item.id, qty - 1);
  };

  return (
    <div className="group bg-card rounded-lg border border-border overflow-hidden transition-all duration-300 hover:shadow-lg hover:-translate-y-0.5 animate-fade-up relative">
      {/* Fly-to-cart animation overlay */}
      {flyAnim && (
        <div className="absolute inset-0 z-10 pointer-events-none">
          <div className="absolute inset-0 bg-accent/10 animate-[flyPulse_0.5s_ease-out]" />
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 animate-[flyToCart_0.5s_ease-in-out_forwards]">
            <div className="h-12 w-12 rounded-full bg-accent/20 flex items-center justify-center">
              <Plus className="h-5 w-5 text-accent" />
            </div>
          </div>
        </div>
      )}

      <div ref={imgRef} className="aspect-square overflow-hidden relative">
        <img
          src={item.image}
          alt={item.name}
          loading="lazy"
          width={512}
          height={512}
          className={`w-full h-full object-cover transition-transform duration-500 group-hover:scale-105 ${flyAnim ? "scale-95 brightness-110" : ""}`}
          style={{ transition: "transform 0.3s, filter 0.3s" }}
        />
        {/* Qty badge on image */}
        {qty > 0 && (
          <div className="absolute top-2 right-2 h-6 min-w-6 px-1.5 rounded-full bg-accent text-accent-foreground text-xs font-bold flex items-center justify-center animate-scale-in shadow-sm">
            {qty}
          </div>
        )}
      </div>
      <div className="p-3 space-y-2">
        <h3 className="font-medium text-foreground text-sm leading-tight truncate">{item.name}</h3>
        <span className="text-accent font-semibold text-sm block">{formatRupiah(item.price)}</span>
        <div className="flex items-center justify-center gap-2">
          {qty > 0 ? (
            <>
              <button
                onClick={handleMinus}
                className="h-8 w-8 flex-shrink-0 rounded-full border border-border flex items-center justify-center text-muted-foreground hover:bg-muted transition-all duration-200 active:scale-90 animate-scale-in"
              >
                <Minus className="h-3.5 w-3.5" />
              </button>
              <span className="text-sm font-bold min-w-[1.5rem] text-center text-foreground animate-scale-in">{qty}</span>
              <button
                onClick={handleAdd}
                className="h-8 w-8 flex-shrink-0 rounded-full bg-primary text-primary-foreground flex items-center justify-center transition-all duration-200 hover:bg-accent hover:scale-110 active:scale-95"
                aria-label={`Tambah ${item.name}`}
              >
                <Plus className="h-3.5 w-3.5" />
              </button>
            </>
          ) : (
            <button
              onClick={handleAdd}
              className="h-8 w-full rounded-full bg-primary text-primary-foreground flex items-center justify-center gap-1.5 transition-all duration-200 hover:bg-accent hover:scale-[1.02] active:scale-95 text-xs font-medium"
              aria-label={`Tambah ${item.name}`}
            >
              <Plus className="h-3.5 w-3.5" />
              Tambah
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
