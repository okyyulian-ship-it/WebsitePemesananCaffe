import { useState } from "react";
import { Coffee, ShoppingBag } from "lucide-react";
import { menuItems, categories, formatRupiah } from "@/data/menu";
import { CartProvider, useCart } from "@/context/CartContext";
import { MenuItemCard } from "@/components/MenuItemCard";
import { OrderSidebar } from "@/components/OrderSidebar";
import { CheckoutModal } from "@/components/CheckoutModal";

function POSContent() {
  const [activeCategory, setActiveCategory] = useState<"makanan" | "minuman" | "ekstra">("makanan");
  const [checkoutOpen, setCheckoutOpen] = useState(false);
  const [cartOpen, setCartOpen] = useState(false);
  const { totalItems, total } = useCart();

  const filteredItems = menuItems.filter((item) => item.category === activeCategory);

  return (
    <div className="min-h-screen flex flex-col lg:flex-row">
      {/* Main Content */}
      <div className="flex-1 flex flex-col min-h-screen">
        {/* Header */}
        <header className="px-6 py-5 border-b border-border flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="h-9 w-9 rounded-full bg-accent/10 flex items-center justify-center">
              <Coffee className="h-4.5 w-4.5 text-accent" />
            </div>
            <div>
              <h1 className="text-xl font-semibold text-foreground leading-none font-sans">Oki Caffe & Resto</h1>
              <p className="text-xs text-muted-foreground mt-0.5">Caffe dan Resto Terbaik di Jakarta</p>
            </div>
          </div>
          {/* spacer for header balance */}
          <div className="w-10 lg:hidden" />
        </header>

        {/* Category Tabs */}
        <div className="px-6 pt-5 pb-2">
          <div className="flex gap-2">
            {categories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setActiveCategory(cat.id)}
                className={`px-5 py-2.5 rounded-full text-sm font-medium transition-all duration-200 ${
                  activeCategory === cat.id
                    ? "bg-primary text-primary-foreground shadow-sm"
                    : "bg-secondary text-muted-foreground hover:bg-muted hover:text-foreground"
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>
        </div>

        {/* Menu Grid */}
        <div className="flex-1 p-6 overflow-y-auto scrollbar-thin">
          <div className="grid grid-cols-2 sm:grid-cols-3 xl:grid-cols-4 gap-4">
            {filteredItems.map((item, i) => (
              <div key={item.id} style={{ animationDelay: `${i * 60}ms` }}>
                <MenuItemCard item={item} />
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Sidebar - Desktop */}
      <div className="hidden lg:block w-[380px] flex-shrink-0">
        <OrderSidebar onCheckout={() => setCheckoutOpen(true)} />
      </div>

      {/* Sidebar - Mobile overlay */}
      {cartOpen && (
        <div className="lg:hidden fixed inset-0 z-40">
          <div className="absolute inset-0 bg-foreground/30 backdrop-blur-sm" onClick={() => setCartOpen(false)} />
          <div className="absolute right-0 top-0 bottom-0 w-[340px] max-w-full animate-slide-in">
            <OrderSidebar onCheckout={() => { setCheckoutOpen(true); setCartOpen(false); }} />
          </div>
        </div>
      )}

      {/* Floating cart button - mobile */}
      {totalItems > 0 && !cartOpen && (
        <button
          onClick={() => setCartOpen(true)}
          className="lg:hidden fixed bottom-6 left-4 right-4 z-30 flex items-center justify-between px-5 py-4 rounded-2xl bg-primary text-primary-foreground shadow-xl animate-fade-up"
        >
          <div className="flex items-center gap-3">
            <div className="relative">
              <ShoppingBag className="h-5 w-5" />
              <span className="absolute -top-2 -right-2 h-5 w-5 bg-accent text-accent-foreground text-[10px] font-bold rounded-full flex items-center justify-center">
                {totalItems}
              </span>
            </div>
            <span className="font-medium text-sm">Lihat Pesanan</span>
          </div>
          <span className="font-bold text-sm">{formatRupiah(total)}</span>
        </button>
      )}

      <CheckoutModal open={checkoutOpen} onClose={() => setCheckoutOpen(false)} />
    </div>
  );
}

export default function Index() {
  return (
    <CartProvider>
      <POSContent />
    </CartProvider>
  );
}
