import cappuccino from "@/assets/menu/cappuccino.jpg";
import croissant from "@/assets/menu/croissant.jpg";
import matcha from "@/assets/menu/matcha.jpg";
import sandwich from "@/assets/menu/sandwich.jpg";
import cake from "@/assets/menu/cake.jpg";
import orangeJuice from "@/assets/menu/orange-juice.jpg";
import nasiGoreng from "@/assets/menu/nasi-goreng.jpg";
import pasta from "@/assets/menu/pasta.jpg";
import fries from "@/assets/menu/fries.jpg";
import wings from "@/assets/menu/wings.jpg";
import salad from "@/assets/menu/salad.jpg";
import pancake from "@/assets/menu/pancake.jpg";
import bruschetta from "@/assets/menu/bruschetta.jpg";
import americano from "@/assets/menu/americano.jpg";
import hotChoco from "@/assets/menu/hot-choco.jpg";
import smoothie from "@/assets/menu/smoothie.jpg";
import lemonTea from "@/assets/menu/lemon-tea.jpg";
import caramelLatte from "@/assets/menu/caramel-latte.jpg";
import sparkling from "@/assets/menu/sparkling.jpg";
import caramelSyrup from "@/assets/menu/caramel-syrup.jpg";
import chocoChips from "@/assets/menu/choco-chips.jpg";
import cheese from "@/assets/menu/cheese.jpg";
import egg from "@/assets/menu/egg.jpg";
import iceCream from "@/assets/menu/ice-cream.jpg";

export interface MenuItem {
  id: string;
  name: string;
  price: number;
  image: string;
  category: "makanan" | "minuman" | "ekstra";
}

export const menuItems: MenuItem[] = [
  // Makanan (7)
  { id: "m1", name: "Croissant Butter", price: 28000, image: croissant, category: "makanan" },
  { id: "m2", name: "Club Sandwich", price: 42000, image: sandwich, category: "makanan" },
  { id: "m3", name: "Chocolate Cake", price: 35000, image: cake, category: "makanan" },
  { id: "m4", name: "Nasi Goreng Spesial", price: 38000, image: nasiGoreng, category: "makanan" },
  { id: "m5", name: "Pasta Aglio Olio", price: 45000, image: pasta, category: "makanan" },
  { id: "m6", name: "Chicken Wings", price: 40000, image: wings, category: "makanan" },
  { id: "m7", name: "Pancake Stack", price: 32000, image: pancake, category: "makanan" },

  // Minuman (7)
  { id: "d1", name: "Cappuccino", price: 32000, image: cappuccino, category: "minuman" },
  { id: "d2", name: "Iced Matcha Latte", price: 36000, image: matcha, category: "minuman" },
  { id: "d3", name: "Fresh Orange Juice", price: 25000, image: orangeJuice, category: "minuman" },
  { id: "d4", name: "Iced Americano", price: 28000, image: americano, category: "minuman" },
  { id: "d5", name: "Hot Chocolate", price: 30000, image: hotChoco, category: "minuman" },
  { id: "d6", name: "Caramel Latte", price: 35000, image: caramelLatte, category: "minuman" },
  { id: "d7", name: "Lemon Tea", price: 22000, image: lemonTea, category: "minuman" },

  // Ekstra (7)
  { id: "e1", name: "Extra Shot Espresso", price: 8000, image: cappuccino, category: "ekstra" },
  { id: "e2", name: "Whipped Cream", price: 5000, image: iceCream, category: "ekstra" },
  { id: "e3", name: "Oat Milk Upgrade", price: 10000, image: matcha, category: "ekstra" },
  { id: "e4", name: "Caramel Syrup", price: 6000, image: caramelSyrup, category: "ekstra" },
  { id: "e5", name: "Choco Chips Topping", price: 7000, image: chocoChips, category: "ekstra" },
  { id: "e6", name: "Extra Cheese", price: 8000, image: cheese, category: "ekstra" },
  { id: "e7", name: "Telur Mata Sapi", price: 7000, image: egg, category: "ekstra" },
];

export const categories = [
  { id: "makanan" as const, label: "Makanan" },
  { id: "minuman" as const, label: "Minuman" },
  { id: "ekstra" as const, label: "Ekstra" },
];

export function formatRupiah(amount: number): string {
  return new Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR", minimumFractionDigits: 0 }).format(amount);
}
